package com.org.gen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JunitRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JunitRestApiApplication.class, args);
	}

}
