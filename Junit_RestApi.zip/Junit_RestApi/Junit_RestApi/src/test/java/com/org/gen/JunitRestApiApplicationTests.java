package com.org.gen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunitRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
